import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Carico il dataset unificato
full_df = pd.read_csv("unified_customer_data.csv", parse_dates=[
    "registration_date", "last_purchase_date", "last_campaign_date"
])

# Imposto la data di riferimento (snapshot)
snapshot_date = pd.to_datetime("2025-04-30")


# Età e registrazione sono già presenti

# Recency = giorni dall'ultimo acquisto
full_df["recency_days"] = (snapshot_date - full_df["last_purchase_date"]).dt.days

# Media spesa per acquisto
full_df["avg_spend_per_purchase"] = full_df["total_spend"] / (full_df["total_purchases"] + 0.01)

# Giorni dall'ultima campagna
full_df["days_since_last_campaign"] = (snapshot_date - full_df["last_campaign_date"]).dt.days

# Flag inattivo (>120 giorni)
full_df["is_inactive"] = full_df["recency_days"] > 120

# Ha acquistato almeno una volta
full_df["has_purchased"] = ~full_df["last_purchase_date"].isna()

# Ha ricevuto almeno una campagna
full_df["was_contacted"] = full_df["num_campaigns"] > 0

# Durata cliente (tenure)
full_df["tenure_days"] = (snapshot_date - full_df["registration_date"]).dt.days
full_df["tenure_months"] = full_df["tenure_days"] / 30

#--------------------------------------------------
#eta
# 
# import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

# Plot
sns.histplot(full_df["age"], bins=20, kde=True)
plt.title("Distribuzione Età Clienti")
plt.xlabel("Età")
plt.ylabel("Numero Clienti")
plt.show()

# Stats
print("Statistiche Età Clienti:")
print(full_df["age"].describe())

# Missing values
print("\nValori mancanti in 'age':", full_df["age"].isna().sum())

# Bucketed ages
age_bins = pd.cut(full_df["age"], bins=[0, 20, 30, 40, 50, 60, 70, 100])
print("\nDistribuzione per fascia d'età:")
print(age_bins.value_counts().sort_index())


#----------------------marketing consent
# Pie chart
full_df["marketing_consent"].value_counts(normalize=True).plot(
    kind="pie", labels=["No", "Sì"], autopct="%1.1f%%", startangle=90
)
plt.title("Consenso Marketing")
plt.ylabel("")
plt.show()

# Value counts
print("Distribuzione consenso marketing:")
print(full_df["marketing_consent"].value_counts())
print("\nDistribuzione % consenso marketing:")
print(full_df["marketing_consent"].value_counts(normalize=True) * 100)





#------------------------------
#numero campagne ricevute

# Histogram
sns.histplot(full_df["num_campaigns"], bins=20, kde=False)
plt.title("Distribuzione Numero di Campagne Ricevute")
plt.xlabel("Numero Campagne")
plt.ylabel("Numero Clienti")
plt.show()

# Stats
print("Statistiche numero campagne ricevute:")
print(full_df["num_campaigns"].describe())

# Missing
print("\nValori mancanti in 'num_campaigns':", full_df["num_campaigns"].isna().sum())


#------------SPESA TOTALE

# Histogram
sns.histplot(full_df["total_spend"], bins=30, kde=True)
plt.title("Distribuzione della Spesa Totale")
plt.xlabel("Totale Spesa (€)")
plt.ylabel("Numero Clienti")
plt.show()

# Stats
print("Statistiche spesa totale:")
print(full_df["total_spend"].describe())

# Missing
print("\nValori mancanti in 'total_spend':", full_df["total_spend"].isna().sum())


#recency-----------------------------------
# Ensure the feature is computed
from datetime import datetime
snapshot_date = pd.to_datetime("2025-04-30")  # or 2025-04-26 if you prefer strict match
full_df["recency_days"] = (snapshot_date - full_df["last_purchase_date"]).dt.days

# Histogram
sns.histplot(full_df["recency_days"], bins=30, kde=True)
plt.title("Giorni dall'Ultimo Acquisto")
plt.xlabel("Giorni")
plt.ylabel("Numero Clienti")
plt.show()

# Stats
print("Statistiche recency_days:")
print(full_df["recency_days"].describe())

# Missing
print("\nValori mancanti in 'recency_days':", full_df["recency_days"].isna().sum())


#----------SPESA MEDIA PER ACQUISTO
# Ensure the feature is computed
full_df["avg_spend_per_purchase"] = full_df["total_spend"] / full_df["total_purchases"]

# Histogram
sns.histplot(full_df["avg_spend_per_purchase"], bins=30, kde=True)
plt.title("Spesa Media per Acquisto")
plt.xlabel("€ per acquisto")
plt.ylabel("Numero Clienti")
plt.show()

# Stats
print("Statistiche spesa media per acquisto:")
print(full_df["avg_spend_per_purchase"].describe())

# Missing
print("\nValori mancanti in 'avg_spend_per_purchase':", full_df["avg_spend_per_purchase"].isna().sum())


#-----------------tenure
snapshot_date = pd.to_datetime("2025-04-30")
full_df["tenure_days"] = (snapshot_date - full_df["registration_date"]).dt.days
print("Statistiche tenure_days:", full_df["tenure_days"].describe())

corr1 = full_df[["tenure_days", "avg_spend_per_purchase"]].corr().iloc[0, 1]
corr2 = full_df[["tenure_days", "recency_days"]].corr().iloc[0, 1]

print(f"Correlazione tenure vs spesa media: {corr1:.2f}")
print(f"Correlazione tenure vs recency: {corr2:.2f}")



###---DISTR paese
print(full_df["country"].value_counts(normalize=True) * 100)


##CLIENTI Inattivi per paesi
inactive_by_country = full_df[full_df["is_inactive"] == True]["country"].value_counts()
print("Clienti inattivi per Paese:")
print(inactive_by_country)


##PERC inattivi per paese
total_by_country = full_df["country"].value_counts()
perc_inactive_by_country = (inactive_by_country / total_by_country * 100).sort_values(ascending=False)
print("\nPercentuale clienti inattivi per Paese:")
print(perc_inactive_by_country)


##SPESA MEDIA CLIENTI PER PAESE avg_spend_by_country = full_df.groupby("country")["total_spend"].mean().sort_values(ascending=False)
avg_spend_by_country = full_df.groupby("country")["total_spend"].mean().sort_values(ascending=False)
print("\nSpesa media per cliente per Paese:")
print(avg_spend_by_country)


##REAT CAMPAGNE
campaigns_by_country = full_df.groupby("country")["num_campaigns"].apply(lambda x: (x > 0).mean())
print("\nPercentuale di clienti con almeno una campagna ricevuta per Paese:")
print(campaigns_by_country.sort_values(ascending=False))


#PRODUTTIVITA MEDIA

full_df["purchase_intensity"] = full_df["total_purchases"] / (full_df["tenure_days"]/30 + 0.01)
print(full_df["purchase_intensity"].describe())


#SEGMENTO PER INTENSITA D ACQUISTO
# Creazione delle fasce in base ai quantili
full_df["intensity_segment"] = pd.qcut(full_df["purchase_intensity"], 
                                       q=[0, 0.33, 0.66, 1], 
                                       labels=["Low", "Medium", "High"])

# Distribuzione per segmento
print("Distribuzione dei clienti per segmento di intensità:")
print(full_df["intensity_segment"].value_counts(dropna=False))

# Verifica valori mancanti (clienti senza transazioni)
print("\nClienti con intensità mancante (probabilmente nessuna transazione):")
print(full_df["intensity_segment"].isna().sum())


#SPESA MEDIA PER SEGMENTO INTENSITA
spesa_media_per_segmento = full_df.groupby("intensity_segment")["avg_spend_per_purchase"].mean()
print("\nSpesa media per acquisto per segmento di intensità:")
print(spesa_media_per_segmento)


#perc clienti cinattivi per segmento
perc_inattivi_per_segmento = full_df.groupby("intensity_segment")["is_inactive"].mean() * 100
print("\nPercentuale di clienti inattivi per segmento di intensità:")
print(perc_inattivi_per_segmento)


#PERC CLIENTI CHE HANNO ricevuto campagne per segmento
campagne_ricevute = full_df.groupby("intensity_segment")["num_campaigns"].apply(lambda x: (x > 0).mean()) * 100
print("\nPercentuale di clienti che hanno ricevuto almeno una campagna per segmento di intensità:")
print(campagne_ricevute)


import pandas as pd
transactions = pd.read_csv("transactions.csv", parse_dates=["event_date"])

snapshot_date = pd.to_datetime("2024-12-31")
future_cutoff = pd.to_datetime("2025-01-01")

# Flag inactive clients as of snapshot
full_df["recency_days"] = (snapshot_date - full_df["last_purchase_date"]).dt.days
full_df["is_inactive_at_snapshot"] = full_df["recency_days"] > 120

# Check if client made any future purchases
future_purchases = transactions[transactions["event_date"] > snapshot_date]
reactivated_ids = set(future_purchases["customer_id"])
full_df["reactivated"] = full_df["customer_id"].isin(reactivated_ids).astype(int)

num_reactivated = full_df["reactivated"].sum()
print(f"Number of reactivated customers: {num_reactivated}")

campaigns = pd.read_csv("campaign_tasks.csv", parse_dates=["start_date", "end_date", "last_modified_date"])

latest_campaigns = campaigns.sort_values("last_modified_date").drop_duplicates("customer_id", keep="last")
latest_campaigns = latest_campaigns[["customer_id", "campaign_channel"]]

channel_effectiveness = full_df[["customer_id", "reactivated"]].merge(
    latest_campaigns, on="customer_id", how="left"
)

reactivation_by_channel = (
    channel_effectiveness.groupby("campaign_channel")["reactivated"]
    .agg(["mean", "count"])
    .rename(columns={"mean": "reactivation_rate", "count": "num_customers"})
    .sort_values("reactivation_rate", ascending=False)
)

print(reactivation_by_channel)
