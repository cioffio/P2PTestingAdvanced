import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    roc_auc_score,
    roc_curve
)
import matplotlib.pyplot as plt
from sklearn.tree import export_text
import seaborn as sns

# ---------------------
# STEP 1: Caricamento del dataset ingegnerizzato
# ---------------------
df = pd.read_csv("dormancy_model_dataset.csv", parse_dates=["dormancy_start"])

y = df["returned_after_dormancy"]  # Target binario: 1 se il cliente si riattiva, 0 altrimenti
X = df.drop(columns=["customer_id", "dormancy_start", "returned_after_dormancy"])

# ---------------------
# STEP 2: Train/Test Split stratificato
# ---------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, stratify=y, test_size=0.2, random_state=42
)

# ---------------------
# STEP 3: Preprocessing con scaling e encoding
# ---------------------
categorical = ["gender", "country"]
numerical = X.select_dtypes(include=["int64", "float64"]).columns.difference(categorical).tolist()

preprocessor = ColumnTransformer(transformers=[
    ("num", StandardScaler(), numerical),
    ("cat", OneHotEncoder(handle_unknown="ignore"), categorical)
])

# ---------------------
# STEP 4: Pipeline con Random Forest
# ---------------------
model = Pipeline(steps=[
    ("preprocess", preprocessor),
    ("clf", RandomForestClassifier(n_estimators=200, max_depth=10, class_weight="balanced", random_state=42))
])

model.fit(X_train, y_train)

# ---------------------
# STEP 5: Valutazione del modello
# ---------------------
y_pred = model.predict(X_test)
y_prob = model.predict_proba(X_test)[:, 1]

print("\n🔍 Classification Report:")
print(classification_report(y_test, y_pred))

print("\n🔍 Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))

print("\n🔍 ROC AUC Score:", roc_auc_score(y_test, y_prob))

# ---------------------
# STEP 6: ROC Curve
# ---------------------
fpr, tpr, thresholds = roc_curve(y_test, y_prob)
plt.figure(figsize=(6, 5))
plt.plot(fpr, tpr, label=f"ROC Curve (AUC = {roc_auc_score(y_test, y_prob):.2f})")
plt.plot([0, 1], [0, 1], linestyle="--", color="gray")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("Receiver Operating Characteristic (ROC)")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# ---------------------
# STEP 7: Feature Importance
# ---------------------
ohe = model.named_steps["preprocess"].named_transformers_["cat"]
encoded_feature_names = ohe.get_feature_names_out(categorical)
feature_names = numerical + list(encoded_feature_names)

importances = model.named_steps["clf"].feature_importances_
feat_series = pd.Series(importances, index=feature_names).sort_values(ascending=False)

# Stampa le top 20 feature più importanti
print("\n📊 Top 20 Feature Importances:")
print(feat_series.head(20).to_string())

# Salvataggio opzionale su CSV
feat_series.to_csv("feature_importances.csv")

# Plot delle feature importance
plt.figure(figsize=(10, 6))
feat_series.head(20).plot(kind="barh", color="teal")
plt.title("Top 20 Feature Importances")
plt.gca().invert_yaxis()
plt.tight_layout()
plt.show()

# ---------------------
# Analisi delle Top 10 Features rispetto alla variabile target
# ---------------------
X_full = X.copy()
X_full["returned_after_dormancy"] = y

top_features = feat_series.head(10).index.tolist()

print("\n📊 Valori medi/diversi delle Top Features per classe di riattivazione:")
for col in top_features:
    print(f"\n🔹 Feature: {col}")
    if col in numerical:
        print(X_full.groupby("returned_after_dormancy")[col].describe()[["mean", "std"]])
    else:
        value_counts = (
            X_full.groupby("returned_after_dormancy")[col].value_counts(normalize=True).unstack(fill_value=0)
        )
        print(value_counts.round(2))

# ---------------------
# Esportazione dell'albero decisionale semplificato (1 su 200)
# ---------------------
tree = model.named_steps["clf"].estimators_[0]
rules = export_text(tree, feature_names=feature_names, max_depth=4)

print("\n🌲 Albero Decisionale di Esempio (profondità 4):")
print(rules)
