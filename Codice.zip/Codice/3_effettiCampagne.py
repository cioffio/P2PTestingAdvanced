import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# === Caricamento del dataset ===
df = pd.read_csv("dormancy_campaign_effects.csv", parse_dates=["dormancy_start", "dormancy_end"])
df = df[df["campaigns_during_dormancy"] > 0]  # Consideriamo solo clienti che hanno ricevuto almeno una campagna

# === Definizione dei canali ===
channels = ["received_email", "received_sms", "received_letter", "received_call"]
channel_names = {
    "received_email": "Email",
    "received_sms": "SMS",
    "received_letter": "Letter",
    "received_call": "Call"
}
fendi_palette = ["#c7b198", "#6e5849", "#a68a64", "#dbc1ac"]  # Palette ispirata a Fendi

# === 1. Tasso di riattivazione per canale ===
channel_stats = []
for ch in channels:
    subset = df[df[ch] == 1]
    rate = subset["returned_after_dormancy"].mean()
    channel_stats.append({
        "Channel": channel_names[ch],
        "Reactivation Rate": rate,
        "N": len(subset)
    })

channel_df = pd.DataFrame(channel_stats)
print("\n🔹 Tassi di Riattivazione per Canale:")
print(channel_df.to_string(index=False, float_format="%.2f"))

plt.figure(figsize=(8, 5))
sns.barplot(data=channel_df, x="Channel", y="Reactivation Rate", palette=fendi_palette)
plt.title("\ud83d\udcc8 Tasso di Riattivazione per Canale")
plt.ylim(0, 1)
plt.ylabel("Tasso di Riattivazione")
plt.grid(axis='y', linestyle="--", alpha=0.5)
for i, row in channel_df.iterrows():
    plt.text(i, row["Reactivation Rate"] + 0.02, f"{row['Reactivation Rate']:.0%}\nN={row['N']}", ha="center", fontsize=9)
plt.tight_layout()
plt.show()

# === 2. Tasso di riattivazione per canale e genere ===
gender_plot_data = []
for ch in channels:
    temp = df[df[ch] == 1]
    grouped = temp.groupby("gender")["returned_after_dormancy"].mean().reset_index()
    grouped["Channel"] = channel_names[ch]
    gender_plot_data.append(grouped)
gender_df = pd.concat(gender_plot_data)

print("\n🔹 Tassi di Riattivazione per Canale e Genere:")
print(gender_df.pivot(index="Channel", columns="gender", values="returned_after_dormancy").round(2))

plt.figure(figsize=(10, 6))
sns.barplot(data=gender_df, x="Channel", y="returned_after_dormancy", hue="gender", palette=fendi_palette)
plt.title("\ud83d\udcca Tasso di Riattivazione per Canale e Genere")
plt.ylabel("Tasso di Riattivazione")
plt.ylim(0, 1)
plt.grid(axis='y', linestyle="--", alpha=0.5)
plt.tight_layout()
plt.show()

# === 3. Tasso di riattivazione per paese (Top 5) ===
top_countries = df["country"].value_counts().nlargest(5).index.tolist()
df_top = df[df["country"].isin(top_countries)]

country_plot_data = []
for ch in channels:
    temp = df_top[df_top[ch] == 1]
    grouped = temp.groupby("country")["returned_after_dormancy"].mean().reset_index()
    grouped["Channel"] = channel_names[ch]
    country_plot_data.append(grouped)
country_df = pd.concat(country_plot_data)

print("\n🔹 Tassi di Riattivazione per Paese e Canale (Top 5 Paesi):")
print(country_df.pivot(index="country", columns="Channel", values="returned_after_dormancy").round(2))

plt.figure(figsize=(12, 6))
sns.barplot(data=country_df, x="country", y="returned_after_dormancy", hue="Channel", palette=fendi_palette)
plt.title("\ud83c\udf0d Tasso di Riattivazione per Paese e Canale")
plt.ylabel("Tasso di Riattivazione")
plt.ylim(0, 1)
plt.grid(axis='y', linestyle="--", alpha=0.5)
plt.tight_layout()
plt.show()
