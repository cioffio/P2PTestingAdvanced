import pandas as pd
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.cluster import KMeans
from sklearn.impute import SimpleImputer
import matplotlib.pyplot as plt
import seaborn as sns

# === STEP 1: Load dataset ===
df = pd.read_csv("dormancy_model_dataset.csv", parse_dates=["dormancy_start"])

# === STEP 2: Drop unused columns and define target ===
df = df.drop(columns=["customer_id", "dormancy_start"])
target = df["returned_after_dormancy"]
X = df.drop(columns=["returned_after_dormancy"])

# === STEP 3: Identify feature types ===
categorical = ["gender", "country"]
numerical = X.select_dtypes(include=["int64", "float64"]).columns.difference(categorical).tolist()

# === STEP 4: Preprocessing pipeline (includes imputation to fix NaN issue) ===
preprocessor = ColumnTransformer([
    ("num", Pipeline([
        ("imputer", SimpleImputer(strategy="mean")),
        ("scaler", StandardScaler())
    ]), numerical),
    ("cat", Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", OneHotEncoder(handle_unknown="ignore"))
    ]), categorical)
])

# === STEP 5: Transform features ===
X_processed = preprocessor.fit_transform(X)

# === STEP 6: Clustering ===
kmeans = KMeans(n_clusters=5, random_state=42)
clusters = kmeans.fit_predict(X_processed)

# === STEP 7: Attach cluster labels ===
df["cluster"] = clusters
df["returned_after_dormancy"] = target  # to be sure

# === STEP 8: Analyze segments ===
summary = (
    df.groupby("cluster")
    .agg(
        total_customers=("returned_after_dormancy", "count"),
        reactivated=("returned_after_dormancy", "sum"),
        avg_total_spent=("total_spent", "mean"),
        avg_freq=("purchase_frequency_pre_dormancy", "mean"),
        avg_days_between=("avg_days_between_purchases", "mean")
    )
)
summary["reactivation_rate"] = summary["reactivated"] / summary["total_customers"]

# === STEP 9: Print + Plot Reactivation Rate ===
print("\n📊 Segment Summary by Cluster:")
print(summary.sort_values("reactivation_rate", ascending=False).to_string(float_format="%.2f"))

plt.figure(figsize=(8, 5))
sns.barplot(data=summary.reset_index(), x="cluster", y="reactivation_rate", palette="Blues_d")
plt.title("Reactivation Rate by Discovered Cluster")
plt.ylabel("Reactivation Rate")
plt.xlabel("Cluster")
plt.grid(True, linestyle="--", alpha=0.5)
plt.tight_layout()
plt.show()

# === STEP 10: Successful Campaigns per Cluster ===
campaign_stats = df.groupby("cluster")["num_campaigns_successful"].agg(["mean", "median", "std", "min", "max", "count"]).round(2)

print("\n📊 Successful Campaigns per Cluster:")
print(campaign_stats)

# === STEP 11: Compare Campaign Success vs Reactivation Status by Cluster ===
campaign_comparison = (
    df.groupby(["cluster", "returned_after_dormancy"])["num_campaigns_successful"]
    .agg(["mean", "count"])
    .round(2)
    .rename(columns={"mean": "avg_successful_campaigns", "count": "n_customers"})
)

print("\n📊 Campaign Success vs Reactivation by Cluster:")
print(campaign_comparison)

# === STEP 12: Plot Campaign Engagement by Cluster and Reactivation ===
plt.figure(figsize=(10, 6))
sns.barplot(data=df, x="cluster", y="num_campaigns_successful", hue="returned_after_dormancy", palette="Set2")
plt.title("Avg Successful Campaigns by Cluster and Reactivation Status")
plt.ylabel("Avg # of Successful Campaigns")
plt.xlabel("Cluster")
plt.grid(True, linestyle="--", alpha=0.5)
plt.tight_layout()
plt.show()
