import pandas as pd
import sys
from ydata_profiling import ProfileReport

# ---------------------
# Load dei datasets
# ---------------------
customers = pd.read_csv("customers.csv")
transactions = pd.read_csv("transactions.csv", parse_dates=["event_date"])
campaigns = pd.read_csv("campaign_tasks.csv", parse_dates=["start_date", "end_date", "last_modified_date"])

# ---------------------
# Esplorazione iniziale: guardo le prime linee per controllare il loading e farmi un'idea dei dati
# ---------------------
print(customers.head())
print(customers.info())

print(transactions.head())
print(transactions.info())

print(campaigns.head())
print(campaigns.info())

# ---------------------
# Controllo struttura del dataset prima di una possibile join tra le diverse fonti
# ---------------------

# Controllo le chiavi, in questo caso customer_id, che mi conferma che c'è una riga per cliente
print("Customer ID univoci:", customers["customer_id"].nunique())
print("Numero righe customers:", len(customers))
print(customers["customer_id"].nunique() == len(customers))  # Deve essere True

# Controllo quante transazioni ci sono per cliente e il tipo di relazione
print("Customer ID univoci in transactions:", transactions["customer_id"].nunique())
print("Numero righe transactions:", len(transactions))
print(transactions["customer_id"].nunique() < len(transactions))  # Deve essere True
print(transactions.groupby("customer_id").size().describe())  # Distribuzione numero transazioni

# Controllo quante campagne ci sono per cliente e il tipo di relazione
print("Customer ID univoci in campaigns:", campaigns["customer_id"].nunique())
print("Numero righe campaigns:", len(campaigns))
print(campaigns["customer_id"].nunique() < len(campaigns))  # Deve essere True
print(campaigns.groupby("customer_id").size().describe())  # Distribuzione numero campagne

# ---------------------
# Controllo di integrità: rimuovo ID non presenti nella tabella base
# ---------------------
customer_ids = set(customers["customer_id"])
transactions = transactions[transactions["customer_id"].isin(customer_ids)].copy()
campaigns = campaigns[campaigns["customer_id"].isin(customer_ids)].copy()

# ---------------------
# Aggregazioni prima della join
# ---------------------


# Transazioni: calcolo ultima data acquisto, numero totale e spesa totale
transactions_agg = transactions.groupby("customer_id").agg(
    last_purchase_date=("event_date", "max"),
    total_purchases=("event_date", "count"),
    total_spend=("net_sale_euro", "sum")
).reset_index()

# Campagne: calcolo numero campagne ricevute e ultima data
campaigns_agg = campaigns.groupby("customer_id").agg(
    num_campaigns=("id_campaign", "count"),
    last_campaign_date=("last_modified_date", "max")
).reset_index()

# ---------------------
# Merge finale con customers come tabella base
# ---------------------

customers["age"] = 2025 - customers["birth_year"]  # Feature utile

# Merge con transazioni e campagne
full_df = customers \
    .merge(transactions_agg, on="customer_id", how="left") \
    .merge(campaigns_agg, on="customer_id", how="left")
print("Check columns after merge:", full_df.columns)
print(full_df[["customer_id", "registration_date"]].head())

# ---------------------
# Profiling delle tabelle originali
# ---------------------
# profile_customers = ProfileReport(customers, title="Profiling Clienti", explorative=True)
# profile_customers.to_file("customer_profile_report.html")

# transactions_filtered = transactions[transactions["event_type"] == "purchase"]
# profile_transactions = ProfileReport(transactions_filtered, title="Profiling Transazioni", explorative=True)
# profile_transactions.to_file("transactions_profile_report.html")

# profile_campaigns = ProfileReport(campaigns, title="Profiling Campagne", explorative=True)
# profile_campaigns.to_file("campaign_tasks_profile_report.html")

# ---------------------
# Profiling finale del dataset unificato
# ---------------------
profile_full = ProfileReport(full_df, title="Profiling Dataset Unificato", explorative=True)
profile_full.to_file("merged_dataset_profile_report.html")

# Salva il dataset unificato in CSV per utilizzi successivi (es. feature engineering)
full_df.to_csv("unified_customer_data3.csv", index=False)
print("✅ Dataset unificato salvato in 'unified_customer_data.csv'")


missing_percent = (full_df.isna().mean() * 100).round(1)
missing_summary = missing_percent[missing_percent > 0].sort_values(ascending=False)
print(missing_summary)



# ---------------------
# Serie di plot per il report
# ---------------------
full_df['age'].describe(percentiles=[.25,.5,.75])
full_df['gender'].value_counts(normalize=True)
full_df['country'].value_counts(normalize=True).head(5)
(full_df['marketing_consent'].value_counts(normalize=True)*100).round(1)


plt.figure(figsize=(8, 5))
sns.histplot(full_df['age'], bins=20, kde=True, color='skyblue')
plt.title("Distribuzione dell'età dei clienti")
plt.xlabel("Età")
plt.ylabel("Numero di clienti")
plt.grid(True, linestyle="--", alpha=0.5)
plt.tight_layout()
plt.show()

gender_counts = full_df['gender'].value_counts(normalize=True) * 100

# Bar chart version
plt.figure(figsize=(6, 4))
sns.barplot(x=gender_counts.index, y=gender_counts.values, palette="pastel")
plt.title("Distribuzione per genere (%)")
plt.ylabel("Percentuale")
plt.xlabel("Genere")
plt.ylim(0, 100)
plt.grid(True, linestyle="--", alpha=0.4)
plt.tight_layout()
plt.show()


gender_counts = (full_df['gender'].value_counts(normalize=True) * 100).round(1)
print("📊 Distribuzione per genere (%):\n", gender_counts)


import matplotlib.pyplot as plt

# Labels and values
labels = gender_counts.index.tolist()
sizes = gender_counts.values.tolist()

# Plot
plt.figure(figsize=(6, 6))
wedges, texts, autotexts = plt.pie(
    sizes,
    labels=labels,
    autopct='%1.1f%%',
    startangle=90,
    wedgeprops=dict(width=0.4),
    colors=sns.color_palette("pastel")
)

plt.title("Distribuzione per Genere")
plt.axis('equal')  # Equal aspect ratio ensures donut shape
plt.tight_layout()
plt.show()


top_countries = full_df['country'].value_counts(normalize=True).head(5) * 100

plt.figure(figsize=(8, 4))
sns.barplot(x=top_countries.index, y=top_countries.values, palette="muted")
plt.title("Top 5 Paesi per quota clienti (%)")
plt.ylabel("Percentuale")
plt.xlabel("Paese")
plt.ylim(0, top_countries.max() + 5)
plt.grid(True, linestyle="--", alpha=0.4)
plt.tight_layout()
plt.show()
import matplotlib.pyplot as plt

# Calcolo le percentuali per i 5 paesi principali
country_counts = full_df['country'].value_counts(normalize=True).head(5)
labels = country_counts.index
sizes = (country_counts.values * 100).round(1)  # Percentuali

# Palette ispirata a Fendi
fendi_palette = ["#F9B949", "#D5A961", "#BEA184", "#EFF1F1", "#2A7CAE"]

# Plot
fig, ax = plt.subplots(figsize=(6, 6))
wedges, texts, autotexts = ax.pie(
    sizes,
    labels=labels,
    autopct="%1.1f%%",
    startangle=90,
    colors=fendi_palette,
    pctdistance=0.75,
    wedgeprops=dict(width=0.4)
)

# Migliora lo stile del testo
for text in autotexts:
    text.set_color('black')
    text.set_fontweight('bold')
    text.set_size(10)

ax.set(aspect="equal", title="Distribuzione Top 5 Paesi (%)")
plt.tight_layout()
plt.show()



pct_with_tx = (full_df['total_purchases'].notnull().mean() * 100).round(1)
print(f"% clienti con almeno una transazione: {pct_with_tx}%")

import matplotlib.pyplot as plt
import seaborn as sns

plt.figure(figsize=(8, 5))
sns.histplot(full_df['total_spend'].dropna(), bins=40, color='#A67B5B')  # Colore Fendi: bronzo
plt.title("Distribuzione della Spesa Totale per Cliente", fontsize=14)
plt.xlabel("Totale Spesa (€)", fontsize=12)
plt.ylabel("Numero di Clienti", fontsize=12)
plt.grid(True, linestyle='--', alpha=0.3)
plt.tight_layout()
plt.show()
