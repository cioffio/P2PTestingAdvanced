import pandas as pd
from datetime import timedelta
import numpy as np
# === Load data ===
customers = pd.read_csv("customers.csv", parse_dates=["registration_date"], dayfirst=True)
transactions = pd.read_csv("transactions.csv", parse_dates=["event_date"], dayfirst=True)
campaigns = pd.read_csv("campaign_tasks.csv", parse_dates=["start_date", "end_date", "last_modified_date"], dayfirst=True)

# === Constants ===
DORMANCY_GAP = timedelta(days=120)
FEATURE_WINDOW = timedelta(days=180)
CUTOFF_DATE = pd.Timestamp("2024-12-31")

# === Filter and sort ===
transactions = transactions[transactions["event_type"] == "purchase"]
transactions = transactions.sort_values(["customer_id", "event_date"])

# === Top campaign subjects ===
top_subjects = campaigns["activity_subject"].value_counts().nlargest(10).index.tolist()

features = []

for cust_id, tx_group in transactions.groupby("customer_id"):
    tx_dates = tx_group["event_date"].tolist()
    last_tx = tx_dates[-1]

    # CASE A: Dormant and never returned
    if last_tx + DORMANCY_GAP <= CUTOFF_DATE:
        inactivity_start = last_tx + DORMANCY_GAP
        dormancy_trigger = last_tx
        returned_flag = 0
    else:
        dormant = False
        for i in range(len(tx_dates) - 1):
            gap = tx_dates[i + 1] - tx_dates[i]
            if gap >= DORMANCY_GAP and tx_dates[i] + DORMANCY_GAP <= CUTOFF_DATE:
                dormancy_trigger = tx_dates[i]
                inactivity_start = dormancy_trigger + DORMANCY_GAP
                returned_flag = 1
                dormant = True
                break
        if not dormant:
            continue

    # === Transaction features BEFORE dormancy trigger ===
    tx_window = tx_group[
        (tx_group["event_date"] <= dormancy_trigger) &
        (tx_group["event_date"] >= dormancy_trigger - FEATURE_WINDOW)
    ]
    num_tx = tx_window.shape[0]
    total_spent = tx_window["net_sale_euro"].sum()
    avg_amount = tx_window["net_sale_euro"].mean() if num_tx > 0 else 0
    num_categories = tx_window["product_category"].nunique()
    last_tx_date = tx_window["event_date"].max()
    days_since_last_tx = (dormancy_trigger - last_tx_date).days if pd.notnull(last_tx_date) else 999

    # Advanced TX features
    full_tx = tx_group[tx_group["event_date"] <= dormancy_trigger]
    full_tx_dates = full_tx["event_date"].tolist()
    if len(full_tx_dates) >= 2:
        gaps = [(full_tx_dates[i + 1] - full_tx_dates[i]).days for i in range(len(full_tx_dates) - 1)]
        avg_days_between = sum(gaps) / len(gaps)
    else:
        avg_days_between = np.nan

    reg_date = customers.loc[customers["customer_id"] == cust_id, "registration_date"]
    if reg_date.empty:
        continue
    reg_date = pd.to_datetime(reg_date.values[0])
    tenure_days = max((dormancy_trigger - reg_date).days, 1)
    purchase_frequency = len(full_tx) / (tenure_days / 30.0)

    high_ticket_tx = int((tx_window["net_sale_euro"] > 1000).any())
    is_multi_category_buyer = int(num_categories >= 2)

    # === Campaign features DURING 120-day dormancy window ===
    camp_window = campaigns[
        (campaigns["customer_id"] == cust_id) &
        (campaigns["start_date"] >= dormancy_trigger) &
        (campaigns["start_date"] <= inactivity_start)
    ]
    num_campaigns_sent = camp_window.shape[0]
    num_campaigns_successful = camp_window[camp_window["campaign_status"] == "Done"].shape[0]
    last_camp_date = camp_window["start_date"].max()
    days_since_last_campaign = (inactivity_start - last_camp_date).days if pd.notnull(last_camp_date) else 999
    unique_channels = camp_window["campaign_channel"].nunique()
    unique_subjects = camp_window["activity_subject"].nunique()

    # Channel flags
    channel_email = int("email" in camp_window["campaign_channel"].values)
    channel_sms = int("sms" in camp_window["campaign_channel"].values)
    channel_letter = int("letter" in camp_window["campaign_channel"].values)
    channel_call = int("call" in camp_window["campaign_channel"].values)

    # Subject one-hot encoding
    subject_features = {
        f"subject_{subj.replace(' ', '_').lower()}": int(subj in camp_window["activity_subject"].values)
        for subj in top_subjects
    }

    # === Customer attributes ===
    cust = customers[customers["customer_id"] == cust_id]
    if cust.empty:
        continue
    cust = cust.iloc[0]
    age = 2025 - cust["birth_year"]
    marketing_consent = cust["marketing_consent"]

    row = {
        "customer_id": cust_id,
        "dormancy_trigger": dormancy_trigger,
        "inactive_start": inactivity_start,
        "returned_after_dormancy": returned_flag,
        "num_tx": num_tx,
        "total_spent": total_spent,
        "avg_amount": avg_amount,
        "num_categories": num_categories,
        "days_since_last_tx": days_since_last_tx,
        "avg_days_between_purchases": avg_days_between,
        "purchase_frequency_pre_dormancy": purchase_frequency,
        "high_ticket_tx": high_ticket_tx,
        "is_multi_category_buyer": is_multi_category_buyer,
        "num_campaigns_sent": num_campaigns_sent,
        "num_campaigns_successful": num_campaigns_successful,
        "days_since_last_campaign": days_since_last_campaign,
        "unique_channels": unique_channels,
        "unique_subjects": unique_subjects,
        "channel_email": channel_email,
        "channel_sms": channel_sms,
        "channel_letter": channel_letter,
        "channel_call": channel_call,
        "age": age,
        "gender": cust["gender"],
        "country": cust["country"],
        "tenure_days": tenure_days,
        "marketing_consent": marketing_consent
    }

    row.update(subject_features)
    features.append(row)

# === Save dataset ===
final_df = pd.DataFrame(features)
final_df.to_csv("dormancy_model_dataset_updated.csv", index=False)
print("✅ Final dataset created:", final_df.shape)
